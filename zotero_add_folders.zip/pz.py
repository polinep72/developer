from pyzotero import zotero
import pandas as pd
import os
from dotenv import load_dotenv
import traceback  # Для более детального вывода ошибок

# Загрузка переменных из .env
load_dotenv()

# Настройки
API_KEY = os.getenv("API_KEY")
LIBRARY_ID = os.getenv("LIBRARY_ID")
LIBRARY_TYPE = os.getenv("LIBRARY_TYPE")

# Проверка, что переменные загружены
print("API_KEY:", API_KEY)
print("LIBRARY_ID:", LIBRARY_ID)
print("LIBRARY_TYPE:", LIBRARY_TYPE)

if not all([API_KEY, LIBRARY_ID, LIBRARY_TYPE]):
    print("Ошибка: Не все переменные окружения (API_KEY, LIBRARY_ID, LIBRARY_TYPE) загружены.")
    print("Убедитесь, что файл .env существует и содержит эти переменные.")
    exit()

# Загрузка CSV
csv_file_path = "zotero_folders.csv"
try:
    df = pd.read_csv(csv_file_path)
except FileNotFoundError:
    print(f"Ошибка: Файл '{csv_file_path}' не найден.")
    exit()
except Exception as e:
    print(f"Ошибка при чтении файла '{csv_file_path}': {e}")
    exit()

if "Folder Name" not in df.columns or "Parent Folder" not in df.columns:
    print("Ошибка: CSV файл должен содержать колонки 'Folder Name' и 'Parent Folder'.")
    exit()

# Подключение к Zotero
try:
    zot = zotero.Zotero(LIBRARY_ID, LIBRARY_TYPE, API_KEY)
    # Опциональная проверка соединения (например, попытаться получить информацию о ключе)
    # zot.key_info()
    print("Успешное подключение к Zotero.")
except Exception as e:
    print(f"Ошибка подключения к Zotero: {e}")
    exit()

# Создание папок
created_folders = {}  # Словарь для хранения {имя_папки: id_папки}

for index, row in df.iterrows():
    parent_folder_name_csv = row["Parent Folder"]
    child_folder_name_csv = row["Folder Name"]

    # Пропускаем строки, где имя папки не указано
    if pd.isna(child_folder_name_csv) or not str(child_folder_name_csv).strip():
        print(f"Пропуск строки {index + 2}: Имя папки (Folder Name) не указано.")
        continue

    child_folder_name = str(child_folder_name_csv).strip()

    parent_collection_id = ""  # По умолчанию - папка верхнего уровня

    if pd.notna(parent_folder_name_csv) and str(parent_folder_name_csv).strip():
        parent_folder_name_clean = str(parent_folder_name_csv).strip()
        if parent_folder_name_clean in created_folders:
            parent_collection_id = created_folders[parent_folder_name_clean]
        else:
            # Это означает, что родительская папка указана, но еще не была создана.
            # CSV должен быть отсортирован так, чтобы родители создавались раньше.
            print(
                f"Предупреждение: Родительская папка '{parent_folder_name_clean}' для папки '{child_folder_name}' не найдена среди уже созданных. "
                f"Проверьте порядок строк в CSV или имя родительской папки. Папка '{child_folder_name}' будет пропущена или создана на верхнем уровне, если это допустимо вашей логикой.")
            # Решите, как поступать: пропустить, создать на верхнем уровне или выдать ошибку
            # В данном случае, если родитель не найден, создастся на верхнем уровне из-за parent_collection_id = ""
            # Если нужна строгая иерархия и пропуск, то:
            # print(f"Папка '{child_folder_name}' будет пропущена.")
            # continue
            pass  # Позволяем создать на верхнем уровне, если родитель не найден, или Zotero API вернет ошибку если parent_collection_id будет невалидным (не пустой строкой)

    # Формирование данных для создания коллекции
    # pyzotero ожидает список словарей для create_collections
    collection_payload = [{"name": child_folder_name}]
    if parent_collection_id:  # Если есть ID родительской папки
        collection_payload[0]["parentCollection"] = parent_collection_id

    try:
        print(
            f"Попытка создания папки: '{child_folder_name}' (родитель ID: '{parent_collection_id if parent_collection_id else 'Нет'}')")

        # Используем zot.create_collections(), она принимает список
        response = zot.create_collections(collection_payload)

        # Отладочный вывод ответа от Zotero
        # print(f"Ответ от Zotero для '{child_folder_name}': {response}")

        # Проверка ответа
        if isinstance(response, dict):
            if "successful" in response and isinstance(response["successful"], dict) and "0" in response["successful"]:
                # Успешно созданный элемент будет под ключом "0" (т.к. мы отправляем один элемент в списке)
                created_item_info = response["successful"]["0"]
                if isinstance(created_item_info, dict) and "key" in created_item_info:
                    collection_key = created_item_info["key"]
                    created_folders[child_folder_name] = collection_key
                    print(f"Создана папка: '{child_folder_name}' (ID: {collection_key})")
                else:
                    print(
                        f"Ошибка: Некорректная структура в 'successful[0]' для папки '{child_folder_name}'. Ответ: {created_item_info}")
            elif "failed" in response and isinstance(response["failed"], dict) and response["failed"]:
                # Если есть ошибки, Zotero API вернет их в секции 'failed'
                failure_info = response["failed"].get("0", "Нет деталей об ошибке")  # "0" т.к. один элемент
                print(f"Ошибка от Zotero API при создании папки '{child_folder_name}': {failure_info}")
            else:
                print(f"Неожиданный, но валидный JSON ответ от Zotero для папки '{child_folder_name}': {response}")
        else:
            # Если response не словарь, это проблема
            print(f"Ошибка: Некорректный тип ответа от Zotero для папки '{child_folder_name}'. "
                  f"Ожидался словарь, получен {type(response)}. Содержимое: {response}")

    except Exception as e:
        print(f"Критическая ошибка (исключение Python) при создании папки '{child_folder_name}': {e}")
        print("Traceback:")
        traceback.print_exc()

print("\nГотово!")
print("Сводка по созданным папкам:")
if created_folders:
    for name, folder_id in created_folders.items():
        print(f"- {name}: {folder_id}")
else:
    print("Ни одной папки не было создано.")